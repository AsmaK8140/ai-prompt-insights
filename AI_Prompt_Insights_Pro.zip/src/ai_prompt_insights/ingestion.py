def load_csv(p): import pandas as pd; return pd.read_csv(p)
