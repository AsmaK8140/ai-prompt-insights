import json,os
from .ingestion import load_csv
from .preprocessing import preprocess
from .ai_prompt import call_llm
def create_insights_report(p): os.makedirs('outputs',exist_ok=True); json.dump({'ai_insights':call_llm('')}, open('outputs/report.json','w'))
