import zipfile, os
with zipfile.ZipFile('project.zip','w') as z:
    for root,_,files in os.walk('.'):
        for f in files:
            if 'project.zip' not in f:
                z.write(os.path.join(root,f))