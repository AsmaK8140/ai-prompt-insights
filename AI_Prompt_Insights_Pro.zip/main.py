from src.ai_prompt_insights.generate_report import create_insights_report
create_insights_report('data/sales_data.csv')
